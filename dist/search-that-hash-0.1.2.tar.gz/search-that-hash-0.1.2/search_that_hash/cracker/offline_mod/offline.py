import subprocess as sp
from mport search_that_hash.cracker.offline_mod import hashcat
# Make a class here that calls both depending on the data provided
