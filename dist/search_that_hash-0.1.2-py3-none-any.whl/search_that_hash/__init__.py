__version__ = "0.1.0"

import __main__ as main

if __name__ == "__main__":
    main.main()
